import db from "../Main/db.js";
import client from "../Main/client.js";


function SpiedMessageInstance(msg, time) {

    let timeArgs = time.toString().split(' ');
    let actualTime = `${timeArgs[0]} ${timeArgs[1]} ${timeArgs[2]} ${timeArgs[3]} ${timeArgs[4]}`

    if (msg.author.id === '726735174229819392') this.author = 'Mueed';
    if (msg.author.id === '949310364565274644') this.author = 'Saira'

    this.messageContent = msg.content;
    this.channel = msg.channel.name;
    this.timeStamp = actualTime;

    this.registerMessage = async function(person) {

        let messages = await db.get(`${person}_db_messages`);
        messages.push(this);
        await db.set(`${person}_db_messages`, messages);

    }

    this.send = async function(person) {

        let consent = await db.get(`${person}_consent`);

        const spyChannel = client.channels.cache.get("954838298088583219");
        if (consent) spyChannel.send(`${person}: \` ${this.messageContent} \``)

    }

}

export {SpiedMessageInstance}