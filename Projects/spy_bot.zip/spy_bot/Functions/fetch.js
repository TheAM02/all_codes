import db from "../Main/db.js";

async function fetch (msg, args, glob) {

    let person;

    if (!args[1]) return msg.reply(`Error: Missing argument \`args[1]: [scope:db_messages]\`.`);
    if (args[1].toString().toLowerCase() !== 'db_messages') return

    if (!args[2]) return msg.reply('Error 400: Missing argument `args[2]: [person:name]`')
    person = args[2].toString().toLowerCase()

    if (person === 'saira') person = 'saira'
    else if (person === "mueed") person = 'mueed'
    else return msg.channel.send('Error 400: `BAD_REQUEST`')

    let cachedMessages = await db.get(`${person}_db_messages`);

    // return console.log(cachedMessages);

    cachedMessages.forEach(item => {
        msg.channel.send(
            `${item.author} at ${item.timeStamp} in ${item.channel}: \` ${item.messageContent} \``
        )
    });

}

export default fetch