import error from '../../Embeds/error.js';

function main (msg, args) {


}