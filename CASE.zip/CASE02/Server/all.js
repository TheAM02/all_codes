let utility = [	// Util
	'AJ',
	'PC'
]


export default {
	utility
}