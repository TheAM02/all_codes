export default {
	name: "CASE utility bot",
	type: "Engine",
	version: "1.10",
	mode: "ALPHA",
	colorCode: {
	
	}
}