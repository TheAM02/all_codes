let utility = [	// Util
	'placeholder01',
	'placeholder02',
	'placeholder03'
], notes = [
	'placeholder01',
	'placeholder02'
]


export default {
	utility,
	notes
}